
### Usage 
  
``` bash  
git clone https://github.com/ghadad/connect4
cd connect4  
node ./play.js
```  
